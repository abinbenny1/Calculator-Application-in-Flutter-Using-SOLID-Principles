import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'dart:math'; // Import for sqrt()

void main() {
  runApp(MyApp());
}

class MyApp extends StatefulWidget {
  @override
  _MyAppState createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  bool isDarkMode = false; // Track dark mode status

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Stylish Calculator',
      theme: isDarkMode
          ? ThemeData.dark().copyWith(
        textTheme: GoogleFonts.poppinsTextTheme(),
        scaffoldBackgroundColor: Colors.black,
      )
          : ThemeData.light().copyWith(
        textTheme: GoogleFonts.poppinsTextTheme(),
      ),
      home: CalculatorScreen(
        isDarkMode: isDarkMode, // Pass dark mode status
        toggleTheme: () {
          setState(() {
            isDarkMode = !isDarkMode;
          });
        },
      ),
    );
  }
}

class CalculatorScreen extends StatefulWidget {
  final bool isDarkMode; // Receive dark mode status
  final VoidCallback toggleTheme; // Pass theme toggle function

  CalculatorScreen({required this.isDarkMode, required this.toggleTheme});

  @override
  _CalculatorScreenState createState() => _CalculatorScreenState();
}

class _CalculatorScreenState extends State<CalculatorScreen> {
  String input = '';
  String output = '';

  // Function to handle button press
  void onButtonPressed(String value) {
    setState(() {
      if (value == 'C') {
        input = '';
        output = '';
      } else if (value == '=') {
        try {
          output = (double.parse(input)).toString(); // Handle floating-point calculations
        } catch (e) {
          output = 'Error';
        }
      } else if (value == '√') {
        try {
          output = sqrt(double.parse(input)).toString(); // Square root calculation
        } catch (e) {
          output = 'Error';
        }
      } else {
        input += value;
      }
    });
  }

  // Build custom button widget
  Widget customButton(String text, Color color, {Color textColor = Colors.white}) {
    return Expanded(
      child: GestureDetector(
        onTap: () => onButtonPressed(text),
        child: Container(
          margin: EdgeInsets.all(8),
          padding: EdgeInsets.symmetric(vertical: 20),
          decoration: BoxDecoration(
            color: color,
            borderRadius: BorderRadius.circular(12),
          ),
          child: Center(
            child: Text(
              text,
              style: TextStyle(
                fontSize: 28,
                fontWeight: FontWeight.bold,
                color: textColor,
              ),
            ),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    // Set the color of the output text based on the theme
    Color outputTextColor = widget.isDarkMode ? Colors.white : Colors.green;

    return Scaffold(
      appBar: AppBar(
        title: Text('Calculator'),
        actions: [
          IconButton(
            icon: Icon(widget.isDarkMode ? Icons.light_mode : Icons.dark_mode), // Access dark mode status from widget
            onPressed: widget.toggleTheme, // Toggle theme on button press
          ),
        ],
      ),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Text(
              input,
              style: TextStyle(fontSize: 48, fontWeight: FontWeight.bold, color: widget.isDarkMode ? Colors.white : Colors.black),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Text(
              output,
              style: TextStyle(fontSize: 48, fontWeight: FontWeight.bold, color: outputTextColor),
            ),
          ),
          SizedBox(height: 20),
          Expanded(
            child: Column(
              children: [
                Row(
                  children: [
                    customButton('7', Colors.blue),
                    customButton('8', Colors.blue),
                    customButton('9', Colors.blue),
                    customButton('/', Colors.orange),
                  ],
                ),
                Row(
                  children: [
                    customButton('4', Colors.blue),
                    customButton('5', Colors.blue),
                    customButton('6', Colors.blue),
                    customButton('*', Colors.orange),
                  ],
                ),
                Row(
                  children: [
                    customButton('1', Colors.blue),
                    customButton('2', Colors.blue),
                    customButton('3', Colors.blue),
                    customButton('-', Colors.orange),
                  ],
                ),
                Row(
                  children: [
                    customButton('0', Colors.blue),
                    customButton('C', Colors.red),
                    customButton('√', Colors.green),
                    customButton('+', Colors.orange),
                  ],
                ),
                Row(
                  children: [
                    customButton('=', Colors.purple), // Equals button
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
