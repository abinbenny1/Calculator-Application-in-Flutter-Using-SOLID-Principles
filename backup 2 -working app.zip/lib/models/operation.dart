abstract class Operation {
  double execute(double num1, double num2);
}
